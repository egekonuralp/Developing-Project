﻿using TechStore.Models;

namespace TechStore.ViewModels
{
    public class ProductDetailViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public decimal Price { get; set; }

        public int Stock { get; set; }

        public string ImageUrl { get; set; } = string.Empty;

        public string Brand { get; set; } = string.Empty;

        public int CategoryId { get; set; }

        public string CategoryName { get; set; } = string.Empty;

        public List<Review> Reviews { get; set; } = new();

        public double AverageRating { get; set; }

        public int ReviewCount { get; set; }

        public bool CanReview { get; set; }

        public bool IsInWishlist { get; set; }

        public List<ProductImage> GalleryImages { get; set; } = new();
    }
}
