﻿namespace TechStore.Models
{
    public class Product
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public decimal Price { get; set; }

        public int Stock { get; set; }

        public string ImageUrl { get; set; } = string.Empty;

        public string Brand { get; set; } = string.Empty;

        public DateTime CreatedDate { get; set; }

        public bool IsActive { get; set; }

        public int CategoryId { get; set; }

        public Category Category { get; set; } = null!;

        public List<Review> Reviews { get; set; } = new();

        public List<WishlistItem> WishlistItems { get; set; } = new();

        public List<ProductImage> Images { get; set; } = new ();
    }
}
